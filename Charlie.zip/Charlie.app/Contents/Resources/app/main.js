const { app, Tray, Menu, nativeImage, BrowserWindow, ipcMain, desktopCapturer, screen} = require('electron')
const ScreenSizeDetector = require('screen-size-detector');
const path = require('path')

try { require('electron-reloader')(module) } catch (_) {}
	
/*
 * Vars
 */

 let tray
 let cam_win = false;
 let cam_win_loop;
 let record_audio = true;
 let win;
 let isRecording = false;
 var menuItems = [
  { label: 'Camera', type: 'submenu', submenu: 
  	[
  		{ label: 'Show', type: 'radio', checked: true, click: createCameraWindow },
  		{ label: 'Hide', type: 'radio', click: closeCameraWindow }
  	]
  },
  // { label: 'Microphone', type: 'submenu', submenu: 
  // 	[
  // 		{ label: 'Record', type: 'radio', checked: true, click: recordAudio },
  // 		{ label: 'Mute', type: 'radio', click: muteAudio }
  // 	]
  // }
  { label: 'Quit App', type: 'normal', click: quitApp },
];

function createWindow () {
  win = new BrowserWindow({
    width: 400,
    height: 600,
    frame: false,
    resizable: false,
    webPreferences: {
    	nodeIntegration: true,
      preload: path.join(__dirname, 'views/main/main.js')
    }
  })
  win.loadFile('views/main/view.html')
}

function buildMenu() {
	console.log('building menu...');
	const contextMenu = Menu.buildFromTemplate(menuItems)
	tray.setContextMenu(contextMenu)
}
	
function recordAudio() {
	setAudioState(true);
}

function muteAudio() {
	setAudioState(false);
}

function setAudioState(state) {
	record_audio = state;
	win.webContents.send('audio-state', record_audio);
}

function closeCameraWindow() {
	if(cam_win) {
		cam_win.close();
		cam_win = false;
		cam_win_loop = false;
	}
}

function createCameraWindow() {

	if(cam_win) {
		return;
	}

	cam_win = new BrowserWindow({
    width: 250,
    height: 250,
    frame: false,
    transparent: true,
    webPreferences: {
      preload: path.join(__dirname, 'views/camera/camera.js')
    }
  });

  cam_win.loadFile('views/camera/view.html');
  cam_win.setPosition(10, (screen.getPrimaryDisplay().size.height - (310)))
  cam_win.setBackgroundColor('#00FFFFFF');
  cam_win.setAspectRatio(1);
  cam_win.setVisibleOnAllWorkspaces(true)

  cam_win.webContents.send('recording', isRecording);

  if(!cam_win_loop) {
  	cam_win_loop = () => { 
  		return setTimeout(() => {
		  	if(typeof cam_win == 'object' && cam_win_loop) {
		  		cam_win.setAlwaysOnTop(isRecording);
		  		cam_win_loop();
		  		console.log('looping');
		  	}
		  },100);
	  };

	  cam_win_loop();
	  
  }
}

function quitApp() {
	app.quit();
}

function startRecording() {
	// win.webContents.send('recording', true);
}

function stopRecording() {
	win.webContents.send('recording', false);
}

ipcMain.on('display-camera', (event, arg) => {
	createCameraWindow();
	event.returnValue = true;
});

ipcMain.on('exit-app', (event, arg) => {
	quitApp();
	event.returnValue = true;
});

ipcMain.on('start-recording', (event, arg) => {
	isRecording = true;
	if(cam_win) {
		cam_win.webContents.send('recording', true);
	}
	event.returnValue = true;
});

ipcMain.on('end-recording', (event, arg) => {
	isRecording = false;
	if(cam_win) {
		cam_win.webContents.send('recording', false);
	}
	event.returnValue = true;
});

ipcMain.on('stop-recording', (event, arg) => {
	isRecording = false;
	win.webContents.send('recording', false);
	win.focus();
	event.returnValue = true;
});

app.whenReady().then(() => {
  	createWindow()
  	createCameraWindow();

  	tray = new Tray('./res/taskbar-white.png')
  	buildMenu();
  	tray.setToolTip('Charlie')

	app.on('activate', function () {
		if (BrowserWindow.getAllWindows().length === 0) createWindow()
	})

})

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})