const { ipcRenderer,desktopCapturer } = require('electron');

// const dialog = electron.remote.dialog;


window.addEventListener('DOMContentLoaded', (event) => {

  var rec = null;
  const download = document.getElementById('download');
  const Charlie = {
    recordAudio: true,
    sourceList: [],
    getSourceList: function(updateUI) {
      var $this = this;
      desktopCapturer.getSources({ types: ['window', 'screen'] }).then(async sources => {
        Charlie.sourceList = sources;
        if(updateUI) {
          $this.updateSourceListUI();
        }
      });
    },
    updateSourceListUI: function() {
      var ul = document.getElementById('sources');
      ul.innerHTML = '';
      var first_item = true;
      for (const source of this.sourceList) {
        if(source.name.substring(0, 'charlie'.length) !== 'Charlie') {
          var id = 'screen-' + (Date.now().toString(36) + Math.random().toString(36).substr(2, 5)).toUpperCase();
          ul.innerHTML += '<li screen_id="'+source.id+'" id="'+id+'" class="collection-item screen-item '+(first_item ? 'first-item' : '')+'"><img src="' + source.thumbnail.toDataURL() + '"/> <span>' + source.name + '</span></li>';
          first_item = false;
        }
      }

      ul.innerHTML += '<li class="collection-item" id="view-more"><span>View All..</span></li>';

      document.getElementById('view-more').addEventListener('click', (e) => {
        if(ul.classList.contains('view-all')) {
          ul.classList.remove('view-all');
          document.getElementById('view-more').innerHTML = '<span>View All..</span>';
        } else {
          ul.classList.add('view-all');
          document.getElementById('view-more').innerHTML = '<span>View Less..</span>';
        }
      });
    },
    mergeAudioStreams: function(desktopStream, voiceStream) {
      const context = new AudioContext();
      const destination = context.createMediaStreamDestination();
      let hasDesktop = false;
      let hasVoice = false;
      if (desktopStream && desktopStream.getAudioTracks().length > 0) {
        // If you don't want to share Audio from the desktop it should still work with just the voice.
        const source1 = context.createMediaStreamSource(desktopStream);
        const desktopGain = context.createGain();
        desktopGain.gain.value = 0.7;
        source1.connect(desktopGain).connect(destination);
        hasDesktop = true;
      }
      
      if (voiceStream && voiceStream.getAudioTracks().length > 0) {
        const source2 = context.createMediaStreamSource(voiceStream);
        const voiceGain = context.createGain();
        voiceGain.gain.value = 0.7;
        source2.connect(voiceGain).connect(destination);
        hasVoice = true;
      }
        
      return (hasDesktop || hasVoice) ? destination.stream.getAudioTracks() : [];
    },
    startRecording: function(config) {
      // desktopCapturer.getSources({ types: ['window', 'screen'] }).then(async sources => {
      (async () => {
        try {

          console.log('recording');

          const audio = false;
          const mic = Charlie.recordAudio;

          const desktopStream = await navigator.mediaDevices.getUserMedia({
            audio: audio,
            video: {
              mandatory: {
                chromeMediaSource: 'desktop',
                chromeMediaSourceId: config.id,
                minWidth: 1280,
                maxWidth: 1280,
                minHeight: 720,
                maxHeight: 720
              }
            }
          });

          if (mic === true) {
            voiceStream = await navigator.mediaDevices.getUserMedia({ video: false, audio: mic });
          }

          let tracks = [
            ...desktopStream.getVideoTracks(), 
            ...Charlie.mergeAudioStreams(desktopStream, voiceStream)
          ];

          var url;
          let stream = new MediaStream(tracks);
          const blobs = [];
          var blob;

          rec = new MediaRecorder(stream, {mimeType: 'video/webm; codecs=vp8,opus'});
          rec.ondataavailable = (e) => blobs.push(e.data);
          rec.onstop = async () => {
            ipcRenderer.sendSync('end-recording', '');
            clearInterval(recording_time);
            recording_time_secs = 0;
            document.getElementById('video-preview-time').innerHTML = '00:00:00';
            document.getElementById('video-preview').classList.remove('preview');
            document.getElementById('stop-recording').classList.remove('active');
            //document.getElementById('view-handle').classList.add('active');
            stream.getTracks().forEach(s=>s.stop())
            stream = null;
            tracks = [];
            
            blob = new Blob(blobs, {type: 'video/mp4'});
            url = window.URL.createObjectURL(blob);
            download.href = url;

            const t = new Date();
            const date = ('0' + t.getDate()).slice(-2);
            const month = ('0' + (t.getMonth() + 1)).slice(-2);
            const year = t.getFullYear();
            const hours = ('0' + t.getHours()).slice(-2);
            const minutes = ('0' + t.getMinutes()).slice(-2);
            const seconds = ('0' + t.getSeconds()).slice(-2);
            const time = `${year}-${month}-${date}, ${hours}:${minutes}:${seconds}`;

            download.download = 'Recording-'+time+'.webm';
            blob = [];
            rec = false;

            var clickEvent = new MouseEvent("click", {
                "view": window,
                "bubbles": true,
                "cancelable": false
            });

          download.dispatchEvent(clickEvent);

          };

          const video = document.querySelector('video');
          document.getElementById('video-preview').classList.add('preview');
          //document.getElementById('view-handle').classList.add('active');
          video.srcObject = desktopStream;
          video.onloadedmetadata = (e) => { video.play() }
          rec.start();
          ipcRenderer.sendSync('start-recording', '');
          document.getElementById('stop-recording').classList.add('active');

          var recording_time_secs = 0;
          var recording_time = setInterval(() => {
            recording_time_secs++;
            document.getElementById('video-preview-time').innerHTML = new Date(recording_time_secs * 1000).toISOString().substr(11, 8);
          }, 1000);

        } catch (e) {
          console.log(e);
        }
      })();
      // });
    }
  };

  ipcRenderer.on('audio-state', (event, arg) => {
    Charlie.recordAudio = arg;
  });

  ipcRenderer.on('recording', (event, arg) => {
    if(!arg) {
      if(rec) {
        rec.stop();
      }
    }
  });

  Charlie.getSourceList(true);

  document.getElementById('app-exit').addEventListener('click', (e) => {
    ipcRenderer.sendSync('exit-app', '');
  });

  document.addEventListener('click',function(e){
    if(e.target && e.target.classList.contains('screen-item')) {
      var screen_id = e.target.getAttribute('screen_id');
      var screen_type = screen_id.indexOf('window') > -1 ? 'window' : 'desktop';
      Charlie.startRecording({
        source: screen_type,
        id: screen_id
      });
    }
  });


  document.getElementById('refresh-source-list').addEventListener('click', (e) => {
    Charlie.getSourceList(true);
    document.getElementById('refresh-source-list').classList.add('rotate');
    setTimeout(() => {
      document.getElementById('refresh-source-list').classList.remove('rotate');
    }, 1000);
  });

  document.getElementById('stop-recording-button').addEventListener('click', (e) => {
    document.getElementById('stop-recording').classList.remove('active');
    rec.stop();
  });


});