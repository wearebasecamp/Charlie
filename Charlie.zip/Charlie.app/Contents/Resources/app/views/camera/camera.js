const { ipcRenderer } = require('electron');

window.addEventListener('DOMContentLoaded', (event) => {

  var video = document.querySelector("#cameraView");

  document.getElementById('stop-recording').addEventListener('click', (e) => {
    ipcRenderer.sendSync('stop-recording', '');
    document.getElementById('stop-recording').classList.remove('active');
  });

  ipcRenderer.on('recording', (event, arg) => {
    if(arg) {
      document.getElementById('stop-recording').classList.add('active');
    } else {
      document.getElementById('stop-recording').classList.remove('active');
    }
  }); 


  if (navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: true, audio: false })
      .then(function (stream) {
        video.srcObject = stream;
      })
      .catch(function (err0r) {
        console.log("Something went wrong!");
      });
  }
});